<footer class=footer-box style="margin-top:400px;">
      <div class=row>
        <div class="col-lg-4">
          <h3>kabjhsiAHD</h3>
          <p>jhhisgfiagiagsifgaifgais</p>
        </div>
      <div class="col-lg-4">
        <ul>
          <li>
          <a href=#>join</a>
          </li>
          <li><a href="#">maintanance</a></li>
          <li><a href="#">languagepacks</a></li>
        </ul>
      </div>
      <div class="col-lg-4">
        <h3>newsletter</h3>
        <form action=index.html>
        <input type="email" placeholder="Your Email" name="#" required><br>
       <button>Submit</button>
        </form>
     </div>
      </div>
    </footer>
    <div class="footer_bottom">
      <div class="row">
        <div class=col-12>
          &copy; copyright 2202
        </div>
      </div>
    </div>  
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="./slick/slick.js" type="text/javascript" charset="utf-8"></script>
